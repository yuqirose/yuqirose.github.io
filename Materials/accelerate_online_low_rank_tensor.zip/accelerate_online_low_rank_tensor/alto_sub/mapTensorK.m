function [ T,U ] = mapTensorK( T,R,order )
%MAPTENSORK Summary of this function goes here
%   Detailed explanation goes here
T0 = T;
I = size(T);

for i = 1:numel(order)
    tmp = tenmat(T0,order(i));
%     disp(rank(tmp.data));
    [u,s,v] = svds(tmp.data,min(R,I(order(i))));
    tmp = tenmat(u*s*v',tmp.rdims,tmp.cdims,tmp.tsize);
    T0 = tensor(tmp);
end

[ T,U ] = mapTensorKInit( T0,R,order );

end

