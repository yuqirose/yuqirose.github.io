function [ T0 ,U] = mapTensorKGreedy( T,R,order )
%MAPTENSORK Summary of this function goes here
%   Detailed explanation goes here
T0 = T;
I = size(T);
U = cell(3,1);
for i = 1:numel(order)
    tmp = tenmat(T0,order(i));
%     disp(rank(tmp.data));
    [U{order(i)},s,v] = svds(tmp.data,min(R,I(order(i))));
    tmp = tenmat(U{order(i)}*s*v',tmp.rdims,tmp.cdims,tmp.tsize);
    T0 = tensor(tmp);
end


end

