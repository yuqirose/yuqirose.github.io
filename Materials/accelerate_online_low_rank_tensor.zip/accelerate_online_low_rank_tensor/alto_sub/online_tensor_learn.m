function [ W, objs, ts ] = online_tensor_learn( X,Y, At , nInit, batch_size , nRank )
% main routine for online low-rank tensor learning
% refer to Accelerated Online Low Rank Tensor Learning for Multivariate Spatiotemporal Streams 
% Rose Yu, Dehua Cheng, Yan Liu (ICML 2015)
% Input: 
% - X: predictor, cell array of length 1 x T, each of size Q x M
% - Y: response, cell array of length 1 x T, each of size P x M
% - At: 
%   - if matrix: Laplacian matrix
%   - if tensor: ground truth tensor, for synthetic evaluation 
% - nInit: size of the initial batch
% - batch_size: size of mini-batch
% - nRank: upper bound of the rank
% Output:
% - W: model tensor: P x Q x M
% - obj: objective function value
% - ts: time in second for each iteration



 nSample = length(X);   
 nBatch = floor((nSample-nInit)/batch_size);
 objs = zeros(1,nBatch);
 ts  = objs;
 
 if ismatrix(At) % Cholesky decomposition of Laplacian is known
     % transform Y
     for s = 1:nSample
        Y{s} = At'\Y{s};
     end
 end
     
 [W, Sigma_X,Sigma_Y, D_L,D_R] = solve_online_tensor_init(X(1:nInit), Y(1:nInit), nRank );
 
 for nIter = 1:nBatch
    tic;
     if nIter == nBatch
        X_new = X(nInit + (nBatch-1)*batch_size:end);
        Y_new = Y(nInit + (nBatch-1)*batch_size:end);
     else
     X_new = X(nInit + ((nIter-1)*batch_size:nIter*batch_size-1));
     Y_new = Y(nInit + ((nIter-1)*batch_size:nIter*batch_size-1));
     end
    
     [W,Sigma_X,Sigma_Y , D_L, D_R] = solve_online_tensor_update(W, X_new, Y_new, Sigma_X,Sigma_Y, D_L,D_R,nRank,nIter);
     ts(nIter) = toc;
     
     if ndims(At) ==3 % actual tensor known
        objs(nIter) = norm_fro(W - At)/(norm_fro(At));% parameter estimation error for synthetic            
     else % pure forecasting
        X_test = X(nInit + nIter*batch_size:end);
        Y_test = Y(nInit + nIter*batch_size:end);
        objs(nIter) = least_square_error(W, X_test, Y_test);
     end
     fprintf('batch %d, objs %d\n',nIter, objs(nIter)); 
 end




