function [ T0 ] = mapTensorKSVD( T,T1,R,order )
%MAPTENSORK Summary of this function goes here
%   Detailed explanation goes here
T0 = T;
I = size(T);

i = 1;
tmp = tenmat(T0,order(i));
tmp1 = tenmat(T1,order(i));
[u,~,v] = svds(tmp.data+0.00*mean(abs(tmp.data(:))).*randn(size(tmp.data)),min(R,I(order(i))));
% a = u'*tmp.data*v;
% [u1,~,v1] = svd(eye(R)+0.1.*randn(R,R));
% u = u*u1;
% v = v*v1;
[u1,~,~] = svd([u randn(size(u,1),1)]);
[v1,~,~] = svd([v randn(size(v,1),1)]);

a = u1'*tmp1.data*v1;
[u,s,v] = svds(a,R);
tmp = tenmat(u1*u*s*v'*v1',tmp.rdims,tmp.cdims,tmp.tsize);
% [u,~,v] = svds((u*u')*(tmp.data+0.5*mean(abs(tmp.data(:))).*randn(size(tmp.data)))*(v*v'),min(R,I(order(i))));
% [u,s,v] = svds((u*u')*(tmp.data+tmp1.data)*(v*v'),min(R,I(order(i))));
% tmp = tenmat((u*u')*(tmp1.data)*(v*v'),tmp.rdims,tmp.cdims,tmp.tsize);
T0 = tensor(tmp);

end

