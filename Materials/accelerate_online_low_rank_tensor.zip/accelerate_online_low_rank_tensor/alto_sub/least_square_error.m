function [ err_val ] = least_square_error( A, X_test, Y_test )
%FORECAST_ERROR Summary of this function goes here
%   Detailed explanation goes here
    A = double(A);
    [P,M] = size(Y_test{1});
    err_val = 0;
    nSample = length(X_test);
    for s = 1:nSample
        X_s = X_test{s};
        Y_s = Y_test{s};
        for m = 1:M
            err_val = err_val  + norm(Y_s(:,m)-A(:,:,m)*X_s(:,m),'fro')^2;
        end
    end

    
    err_val = sqrt(err_val/ (nSample * P * M) );
end

