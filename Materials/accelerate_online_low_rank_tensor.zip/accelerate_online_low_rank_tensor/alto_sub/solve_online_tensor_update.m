function [W_out, Sigma_X_out, Sigma_Y_out, D_L, D_R] = solve_online_tensor_update(W, X, Y, Sigma_X,Sigma_Y,D_L,D_R,nRank,nIter)
% update the model with a series of samples. X, Y are cell variables,
% each element is a sample

TA = tensor(W);
nSample = length(Y);
N = 3;
[Q,~] = size(X{1});
[P,M] = size(Y{1});

Sigma_X_out = zeros(Q,Q,M);
Sigma_Y_out = zeros(P,Q,M);

Delta = zeros(P,Q,M);

% step 1:
for m = 1:M % solve for each variable separately
    X_m = zeros(Q,nSample);
    Y_m = zeros(P,nSample);
    for n = 1:nSample
        X_m(:,n) = X{n}(:,m);
        Y_m(:,n) = Y{n}(:,m);
    end
    % Update Sigma_X, Sigma_Y
    B = Sigma_X(:,:,m) *X_m;
    E = B*((eye(nSample) + X_m'*B)\(B'));
    Delta(:,:,m) = 1/nIter * ( Y_m*B' - Sigma_Y(:,:,m)*E - Y_m*X_m'*E + Sigma_Y(:,:,m)*Sigma_X(:,:,m) );
    Sigma_X_out(:,:,m) = Sigma_X(:,:,m) - E;
    Sigma_Y_out(:,:,m) = Sigma_Y(:,:,m) + Y_m*X_m';
end


% step 2: projection 
[ TA, D_L]= ALTO(tensor(nIter*Delta),D_L);

W_out = TA.data;

end


