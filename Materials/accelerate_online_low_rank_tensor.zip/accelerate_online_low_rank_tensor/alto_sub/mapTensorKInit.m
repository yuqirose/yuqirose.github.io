function [ T,U ] = mapTensorKInit( T,R,order )
%MAPTENSORK Summary of this function goes here
%   Detailed explanation goes here
% T0 = T;
I = size(T);
U = cell(3,1);

for i = 1:numel(order)
    tmp = tenmat(T,order(i));
    %     disp(rank(tmp.data));
    [U{order(i)},~,~] = svds(tmp.data,min(R,I(order(i))));
    %     tmp = tenmat(u*s*v',tmp.rdims,tmp.cdims,tmp.tsize);
    %     T0 = tensor(tmp);
end

if R~=size(T,1)
    T = ttm(T, {U{1}',U{2}',U{3}'}, [1 2 3]);
    T = ttm(T, {U{1},U{2},U{3}}, [1 2 3]);
end


end

