function [ W, Sigma_X, Sigma_Y , D_L,D_R] = solve_online_tensor_init(X, Y, nRank)
% get the initial estimation from the first batch 
    [P,~] =  size(Y{1});
    [Q,M] =  size(X{1});
    nSample = length(Y);

    N =3;
   
    W_mat = cell(1,N);
    W_mat{1} =  zeros(P,Q*M);
    W_mat{2} =  zeros(Q, P*M);
    W_mat{3} =  zeros(M, P*Q);

    D_L = cell(1,N); % decomposition
    D_R = cell(1,N);

    Sigma_X = zeros(Q,Q,M);
    Sigma_Y = zeros(P,Q,M);

    % initialize
    for m = 1:M % solve for each variable separately
       X_m = zeros(Q,nSample);
       Y_m = zeros(P,nSample);
       % construct data matrix
       for n = 1:nSample
           X_m(:,n) = X{n}(:,m);
           Y_m(:,n) = Y{n}(:,m);
       end
%        S_X = inv(X_m*X_m'); %Q x Q % may not be invertable
       S_X = inv(X_m*X_m' + 1e-5*eye(Q));
       S_Y = Y_m*X_m'; % P x Q
       W_est = S_Y* S_X;

       W_mat{1}(:, (m-1)*Q+1: m*Q)  = W_est;
       W_mat{2}(:, (m-1)*P+1: m*P)  = W_est';
       W_mat{3}(m, :)  =  reshape(W_est, [1,P*Q]);       
       Sigma_X(:,:,m) = S_X; %Q x Q
       Sigma_Y(:,:,m) = S_Y; % P x Q
    end
    
    W = tensor(reshape(W_mat{1},[P,Q,M]));
    
   [ W,U ] = mapTensorKInit((W),nRank,[1 2 3] );
   W = W.data;
   D_L = U;
   D_R =0;
       
 
end

