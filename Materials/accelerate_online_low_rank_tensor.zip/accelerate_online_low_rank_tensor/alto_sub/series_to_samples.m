function [ X,Y ] = series_to_samples( series, nLag)
%SERIES_TO_SAMPLES : take a series variable 1 x nVar cell,
%and produce a set of data sample pairs 1 x nSample cell

M = length(series);
[P,T] = size(series{1});
Q = P*nLag;
nSample = T-nLag;
X = cell(1,nSample);
Y = cell(1,nSample);
% construct the samples
 for s = 1:T-nLag
     % construct samples
     X_s  = zeros(Q,M);
     for m = 1:M 
         tmp = series{m}(:,s:s+nLag-1);
         X_s(:,m)= tmp(:); % X is of kp (q) x m
     end
     X{s} = X_s;
     Y_s  = zeros(P,M);
     for m = 1:M
         Y_s(:,m) = series{m}(:,s+nLag);
     end
    
     Y{s} = Y_s;
 end


end

