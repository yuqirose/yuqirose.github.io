function [ T1,U1 ] = ALTO( T,U )
%UPDATELRNEW Summary of this function goes here
%   Detailed explanation goes here
U1 = cell(3,1);
R = size(U{1},2);

for i = 1:3
    tmp = randn(size(U{i},1),1);
    tmp = tmp - (U{i}*U{i}')*tmp;
    tmp = tmp./norm(tmp);
    U1{i} = [U{i}  tmp];    
end

T1 = ttm(T,{U1{1}',U1{2}',U1{3}'});

[T1 , U2] = mapTensorKGreedy(T1,R,[1 2 3]);
T1 = ttm(T1,{U1{1},U1{2},U1{3}},[1 2 3]);
for i= 1:3
   U1{i} = U1{i}*U2{i}; 
end

end

