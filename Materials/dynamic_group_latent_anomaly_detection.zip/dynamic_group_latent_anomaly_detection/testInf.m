clear all;
% Source code for dynamic group anomaly detection(d-GLAD) 
% with Monte Carlo Expectation Maximization (MCEM)
% Citation: Yu, Rose, Xinran He, and Yan Liu. "Glad: group anomaly detection in social media analysis." ACM Transactions on Knowledge Discovery from Data (TKDD) 10.2 (2015): 18.

% This script loads the saved initialization and perform model inference
% Group anomaly detection calculates per group role distribution
% Anomaly is defined within the space of role distributions

load('initDGLAD.mat'); % load initialization

drawResultDGLAD(Xp,Y,gPi,gGp,gRp,gTheta,nC);
drawResultDGLAD(Xp,Y,Pi,Gp,Rp,Theta,nC);

[rRp,rGp,rPi,rTheta,riTheta,rB,rBeta,rMu] = MCEMDGLAD(Xp,Y,Rp,Gp,Pi,Theta,initTheta,B,Beta,alpha,Sigma,nC,nM);
drawResultDGLAD(Xp,Y,rPi,rGp,rRp,rTheta,nC);

%Theta = sampleTheta(Gp,Rp,Sigma,ones(rNum));
[GCA,PA] = calAnomalyScore(Xp,rRp,rTheta,rMu,rBeta,0.5);
drawAnomalyDGLAD(GCA,PA,Xp,rRp,rTheta);
