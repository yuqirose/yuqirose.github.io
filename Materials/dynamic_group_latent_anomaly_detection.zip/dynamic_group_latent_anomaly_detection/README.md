This package contains the core source code for 
Yu, Rose, Xinran He, and Yan Liu. "Glad: group anomaly detection in social media analysis." ACM Transactions on Knowledge Discovery from Data (TKDD) 10.2 (2015): 18.

Include in the package
- testInf.m: main procedure for d-GLAD model inference and anomaly detection
- testInfInt.m: initialization for d-GLAD model with static GLAD model
- src/: functions for performing inference for GLAD and d-GLAD models